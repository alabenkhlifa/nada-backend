// src/config/apiConfig.js
export const API_BASE_URL = 'http://localhost:5001/api';